import numpy as np
import matplotlib.pyplot as plt
from sklearn import tree
import pickle

class CircularArray:
    
    def __init__(self, shape):
        """Store buffer in given storage."""
        self.buffer = np.zeros(shape)
        self.populated = np.zeros(shape[0])
        self.low = 0
        self.high = 0
        self.size = shape[0]
        self.count = 0

    def isEmpty(self):
        """Determines if buffer is empty."""
        return self.count == 0

    def isFull(self):
        """Determines if buffer is full."""
        return self.count == self.size
        
    def __len__(self):
        """Returns number of elements in buffer."""
        return self.count
        
    def add(self, value):
        """Adds value to buffer, overwrite as needed."""
        if self.isFull():
            self.low = (self.low+1) % self.size
        else:
            self.count += 1
        self.buffer[self.high] = value
        self.populated[self.high] = 1
        self.high = (self.high + 1) % self.size
    
    def remove(self):
        """Removes oldest value from non-empty buffer."""
        if self.count == 0:
            raise Exception ("Circular Buffer is empty");
        value = self.buffer[self.low]
        self.populated[self.low] = 0
        self.low = (self.low + 1) % self.size
        self.count -= 1
        return value

    def as_array(self):
        if self.isFull():
            return self.buffer
        else:
            return self.buffer[self.populated==1]
    
    def recall(self):
        out_array = np.zeros(self.count)
        for i, item in enumerate(self):
            out_array[i] = item
        return out_array

    
    def __iter__(self):
        """Return elements in the circular buffer in order using iterator."""
        idx = self.low
        num = self.count
        while num > 0:
            yield self.buffer[idx]
            idx = (idx + 1) % self.size
            num -= 1

    def __repr__(self):
        """String representation of circular buffer."""
        if self.isEmpty():
            return 'cb:[]'

        return 'cb:[' + ','.join(map(str,self)) + ']'

class Node():
    pass

class MovementTree():
    def __init__(self, agent_coords, field, max_free_spaces):
        self.root = Node()
        self.root.direction = -1
        self.root.coords = agent_coords

        self.field = (field != 0).astype(int)
        self.visited_spaces = [agent_coords]
        self.directions = [-1]
        self.max_free_spaces = max_free_spaces
        self.num_free_spaces = [0 for _ in range(4)]

    
    def get_free_spaces(self):
        stack = self.get_next_nodes(self.root)

        while len(stack):
            node = stack.pop(0)
            new_nodes = self.get_next_nodes(node)
            stack.extend(new_nodes)
        
        return self.num_free_spaces

    def get_next_nodes(self, node):
        root = node is self.root
        x = node.coords[0]
        y = node.coords[1]
        node.new_nodes = []
        new_coords = [(x+1, y), (x, y+1), (x-1, y), (x, y-1)]
        for i, new_coord in enumerate(new_coords):
            if (self.field[new_coord] == 0) and (new_coord not in self.visited_spaces) and (self.num_free_spaces[node.direction] < self.max_free_spaces):
                new_node = Node()
                new_node.coords = new_coord
                if root:
                    new_node.direction = i
                else:
                    new_node.direction = node.direction
                node.new_nodes.append(new_node)
                self.num_free_spaces[new_node.direction] += 1
                self.visited_spaces.append(new_coord)
                self.directions.append(new_node.direction)
        
        return node.new_nodes
    

class SurvivalTree():
    def __init__(self, game_state):
        agent_coords = game_state['self'][3]

        self.root = Node()
        self.root.direction = None
        self.root.coords = agent_coords
        self.root.time = 0
        self.root.alive = True

        self.visited = np.zeros((5, 17, 17))-1

        self.field = (game_state['field'] != 0).astype(int)
        self.walls = (game_state['field'] == -1).astype(int)
        self.bombs = game_state['bombs'].copy()

        self.bomb_maps = []
        for t in range(5):
            self.bomb_maps.append(self.calc_bomb_map(t))

        self.num_survivable_spaces = [0 for _ in range(5)]
        self.survived = [[] for _ in range(5)]

    def calc_bomb_map(self, t):

        bombs = [(b[0], b[1]-t) for b in self.bombs]
        bombs = [b for b in bombs if b[1] >= -1]

        bomb_map = np.zeros((17+6, 17+6))-2
        bomb_cooldowns = [x[1] for x in bombs]
        bomb_idx_sorted = np.flip(np.argsort(bomb_cooldowns))

        for idx in bomb_idx_sorted:
            bomb = bombs[idx]
            b_x = bomb[0][0]
            b_y = bomb[0][1]
            if np.sum(self.walls[b_x-1:b_x+2, b_y]) == 2:
                bomb_map[b_x+3, b_y:b_y+7] = bomb[1]
            elif np.sum(self.walls[b_x, b_y-1:b_y+2]) == 2:
                bomb_map[b_x:b_x+7, b_y+3] = bomb[1]
            else:
                bomb_map[b_x:b_x+7, b_y+3] = bomb[1]
                bomb_map[b_x+3, b_y:b_y+7] = bomb[1]
        return bomb_map[3:-3,3:-3]
    
    def get_free_spaces(self):
        stack = self.get_next_nodes(self.root)

        while len(stack):
            node = stack.pop(0)
            new_nodes = self.get_next_nodes(node)
            stack.extend(new_nodes)

        return self.num_survivable_spaces

    def get_next_nodes(self, node):
        root = node is self.root
        x = node.coords[0]
        y = node.coords[1]
        node.new_nodes = []
        new_coords = [(x+1, y), (x, y+1), (x-1, y), (x, y-1), (x, y)]
        for i, new_coord in enumerate(new_coords):
            if (self.field[new_coord] == 0) and node.time < 4 and node.alive:
                new_node = Node()
                new_node.coords = new_coord
                new_node.time = node.time + 1
                new_node.alive = node.alive

                if self.bomb_maps[new_node.time][new_node.coords] == -1:
                    new_node.alive = False

                if root:
                    new_node.direction = i
                else:
                    new_node.direction = node.direction

                if new_node.alive and new_node.time == 4 and new_node.coords not in self.survived[new_node.direction]:
                    self.num_survivable_spaces[new_node.direction] += 1
                    self.survived[new_node.direction].append(new_node.coords)

                if new_node.alive:
                    self.visited[new_node.time, new_node.coords[0], new_node.coords[1]] = new_node.direction
                node.new_nodes.append(new_node)
        
        return node.new_nodes
    
class FeatureSelector():

    def __init__(self, game_state=None):
        if game_state != None:
            self.setup(game_state)


    def setup(self, game_state):
        self.game_state = game_state
        self.PADCONST = 3

        self.features = []

        self.field = self.game_state['field']
        self.walls = (self.game_state['field'] == -1).astype(int)
        self.walls_padded = np.pad(self.walls, self.PADCONST, 'edge')
        self.crates = (self.game_state['field'] == 1).astype(int)
        self.crates_padded = np.pad(self.crates, self.PADCONST, 'edge')

        self.agent_pos = self.game_state['self'][3]
        self.agent_pos_x = self.agent_pos[0]
        self.agent_pos_y = self.agent_pos[1]
        self.agent_pos_x_pad = self.agent_pos_x + self.PADCONST
        self.agent_pos_y_pad = self.agent_pos_y + self.PADCONST


    def current_step(self):
        # Current Step Number
        step_number = self.game_state['step']
        self.features.append(step_number)


    def sum_of_crates_around_agent(self):
        # Sum of crates in radius 1 around agent
        self.features.append(np.sum(self.crates_padded[self.agent_pos_x_pad-1:self.agent_pos_x_pad+2, self.agent_pos_y_pad-1:self.agent_pos_y_pad+2]))

        # Sum of self.crates in radius 2 around agent
        self.features.append(np.sum(self.crates_padded[self.agent_pos_x_pad-2:self.agent_pos_x_pad+3, self.agent_pos_y_pad-2:self.agent_pos_y_pad+3]))


    def agent_in_explosion_zone(self):
        # Agent in explosion zone (bool)
        bomb_map = np.zeros((17+2*self.PADCONST, 17+2*self.PADCONST))
        bomb_cooldowns = [x[1] for x in self.game_state['bombs'] if x[1] != 0]
        bomb_idx_sorted = np.flip(np.argsort(bomb_cooldowns))

        for idx in bomb_idx_sorted:
            bomb = self.game_state['bombs'][idx]
            b_x = bomb[0][0]
            b_y = bomb[0][1]
            if np.sum(self.walls[b_x-1:b_x+2, b_y]) == 2:
                bomb_map[b_x + self.PADCONST, b_y:b_y + self.PADCONST + 4] = bomb[1]
            elif np.sum(self.walls[b_x, b_y-1:b_y+2]) == 2:
                bomb_map[b_x:b_x + self.PADCONST + 4, b_y + self.PADCONST] = bomb[1]
            else:
                bomb_map[b_x:b_x + self.PADCONST + 4, b_y + self.PADCONST] = bomb[1]
                bomb_map[b_x + self.PADCONST, b_y:b_y + self.PADCONST + 4] = bomb[1]
        
        self.features.append(bomb_map[self.agent_pos_x_pad, self.agent_pos_y_pad])


    def crates_and_agents_explode(self):
        # Crates that explode if bomb is placed at current location
        custom_bomb_map = np.zeros((17+2*self.PADCONST, 17+2*self.PADCONST))

        b_x = self.agent_pos_x_pad
        b_y = self.agent_pos_y_pad
        if np.sum(self.walls_padded[b_x-1:b_x+2, b_y]) == 2:
            custom_bomb_map[b_x, b_y-3:b_y+4] = 1
        elif np.sum(self.walls_padded[b_x, b_y-1:b_y+2]) == 2:
            custom_bomb_map[b_x-3:b_x+4, b_y] = 1
        else:
            custom_bomb_map[b_x-3:b_x+4, b_y] = 1
            custom_bomb_map[b_x, b_y-3:b_y+4] = 1

        self.features.append(np.sum(custom_bomb_map*self.crates_padded))

        # Number of agents that explode if bomb is placed at current location (and agent doesn't move)
        agents_in_explosion_radius = 0
        for agent in self.game_state['others']:
            other_agent_pos = agent[3]
            other_agent_pos_x = other_agent_pos[0]
            other_agent_pos_y = other_agent_pos[1]
            if custom_bomb_map[other_agent_pos_x + self.PADCONST][other_agent_pos_y + self.PADCONST] == 1:
                agents_in_explosion_radius += 1
        self.features.append(agents_in_explosion_radius)


    def distance_from_bomb_and_cooldown(self):
        # Agent straight distance from next bomb (4 if bomb further away than 4) and its cooldown
        bomb_distance = 4
        bomb_cooldown = 4

        for bomb in [b for b in self.game_state['bombs'] if b[1] != 0]:
            if len(self.game_state['bombs'])==0:
                break
            else:
                if np.sum(self.walls_padded[bomb[0][0]:bomb[0][0]+2*self.PADCONST+1, bomb[0][1]]) == 2 and bomb[1]==self.agent_pos_y:
                    distance = abs(bomb[0][0] - self.agent_pos_x)
                    cooldown = bomb[1]
                    if distance < bomb_distance:
                        bomb_distance = distance
                    if cooldown < bomb_cooldown:
                        bomb_cooldown = cooldown
                elif np.sum(self.walls_padded[bomb[0][0], bomb[0][1]+2*self.PADCONST:bomb[0][1]+1]) == 2 and bomb[0]==self.agent_pos_x:
                    distance = abs(bomb[0][1] - self.agent_pos_y)
                    cooldown = bomb[1]
                    if distance < bomb_distance:
                        bomb_distance = distance
                    if cooldown < bomb_cooldown:
                        bomb_cooldown = cooldown
                elif bomb[0][0]==self.agent_pos_x:
                    distance = abs(bomb[1] - self.agent_pos_y)
                    cooldown = bomb[1]
                    if distance < bomb_distance:
                        bomb_distance = distance
                    if cooldown < bomb_cooldown:
                        bomb_cooldown = cooldown
                elif bomb[0][1]==self.agent_pos_y:
                    distance = abs(bomb[0][0] - self.agent_pos_x)   
                    cooldown = bomb[1] 
                    if distance < bomb_distance:
                        bomb_distance = distance
                    if cooldown < bomb_cooldown:
                        bomb_cooldown = cooldown

        self.features.append(bomb_distance)
        self.features.append(bomb_cooldown)


    def distance_and_rel_coords_and_crates_around_next_agent(self):
        # L1-distance to next agent
        distance_to_next_agent = 30
        closest_agent_x = self.agent_pos_x
        closest_agent_y = self.agent_pos_y
        for agent in self.game_state['others']:
            other_agent_pos = agent[3]
            other_agent_pos_x = other_agent_pos[0]
            other_agent_pos_y = other_agent_pos[1]
            distance_btw_agents = abs(other_agent_pos_x - self.agent_pos_x) + abs(other_agent_pos_y - self.agent_pos_y)
            if distance_btw_agents < distance_to_next_agent:
                distance_to_next_agent = distance_btw_agents
                closest_agent_x = other_agent_pos_x
                closest_agent_y = other_agent_pos_y
        self.features.append(distance_to_next_agent)

        # Relative coordinates of next agent
        self.features.append(closest_agent_x - self.agent_pos_x)
        self.features.append(closest_agent_y - self.agent_pos_y)

        # Crates in radius 1 around next agent
        self.features.append(np.sum(self.crates_padded[closest_agent_x+self.PADCONST-1:closest_agent_x+self.PADCONST+2, closest_agent_y+self.PADCONST-1:closest_agent_y+self.PADCONST+2]))


    def get_agent_pos(self):
        self.features.append(self.game_state['self'][3][0])
        self.features.append(self.game_state['self'][3][1])


    def coins_in_radius_3(self):
        # Coins in radius 3
        coins_in_radius = 0
        for coin in self.game_state['coins']:
            if coin[0]+self.PADCONST in range(self.agent_pos_x_pad - 3, self.agent_pos_x_pad + 4) and coin[1]+self.PADCONST in range(self.agent_pos_y_pad - 3, self.agent_pos_y_pad + 4):
                coins_in_radius += 1
        self.features.append(coins_in_radius)


    def distance_and_rel_coords_and_crates_around_coin(self):
        # L1-distance to next coin
        distance_to_next_coin = 30
        closest_coin_x = self.agent_pos_x
        closest_coin_y = self.agent_pos_y
        for coin in self.game_state['coins']:
            coin_x = coin[0]
            coin_y = coin[1]
            distance_to_coins = abs(coin_x - self.agent_pos_x) + abs(coin_y - self.agent_pos_y)
            if distance_to_coins < distance_to_next_coin:
                distance_to_next_coin = distance_to_coins
                closest_coin_x = coin_x
                closest_coin_y = coin_y
        self.features.append(distance_to_next_coin)

        # Relative coordinates of next coin
        self.features.append(closest_coin_x - self.agent_pos_x)
        self.features.append(closest_coin_y - self.agent_pos_y)

        # Crates in radius 1 around next coin
        self.features.append(np.sum(self.crates_padded[closest_coin_x+self.PADCONST-1:closest_coin_x+self.PADCONST+2, closest_coin_y+self.PADCONST-1:closest_coin_y+self.PADCONST+2]))


    def bomb_possible(self):
        # Is bomb setting possible?
        bomb_possible = self.game_state['self'][2]
        self.features.append(int(bomb_possible))

    def scores(self):
        # Agent score
        agent_score = self.game_state['self'][1]
        self.features.append(agent_score)

        # Other agents scores
        other_agent_scores = [0, 0, 0]
        for idx, agent in enumerate(self.game_state['others']):
            other_agent_scores[idx] = agent[1]
        other_agent_scores = np.sort(other_agent_scores)
        for idx, agent_score in enumerate(other_agent_scores):
            self.features.append(agent_score)


    def sum_crates(self):
        # Sum of all crates
        crate_sum = np.sum(self.crates)
        self.features.append(crate_sum)


    def agent_at_border(self):
        # Agent is at left/right border (bool)
        agent_at_leftright_border = 1 if self.agent_pos_x==1 or self.agent_pos_x==15 else 0
        # agent_at_leftright_border = 1 if (np.sum(self.walls_padded[self.agent_pos_x_pad-3:self.agent_pos_x_pad,self.agent_pos_y])==3 or np.sum(self.walls_padded[self.agent_pos_x_pad:self.agent_pos_x_pad+3, self.agent_pos_y_pad])==3) else 0
        self.features.append(agent_at_leftright_border)

        # Agent is at top/bottom border (bool)
        agent_at_topbottom_border = 1 if self.agent_pos_y==1 or self.agent_pos_y==15 else 0
        # agent_at_topbottom_border = 1 if (np.sum(self.walls_padded[self.agent_pos_x_pad,self.agent_pos_y-3:self.agent_pos_y_pad])==3 or np.sum(self.walls_padded[self.agent_pos_x_pad, self.agent_pos_y_pad:self.agent_pos_y_pad+3])==3) else 0
        self.features.append(agent_at_topbottom_border)
        # all_features.append(features)

    def agent_position_relative_to_wall(self):
        if np.sum(self.walls[self.agent_pos_x-1:self.agent_pos_x+2, self.agent_pos_y]) == 2:
            agent_pos_rel_wall = 1
        elif np.sum(self.walls[self.agent_pos_x, self.agent_pos_y-1:self.agent_pos_y+2]) == 2:
            agent_pos_rel_wall = 2
        else:
            agent_pos_rel_wall = 0
        self.features.append(agent_pos_rel_wall)

    def search_free_space(self):
        tree = MovementTree((self.agent_pos_x, self.agent_pos_y), self.game_state['field'], 7)
        self.features.extend(tree.get_free_spaces()) # gives back 4 features

    def survivable_space(self):
        tree = SurvivalTree(self.game_state)
        self.features.extend(tree.get_free_spaces()) # gives back 5 features

    def eval_all_features(self, game_state):
        self.setup(game_state)
        self.current_step()
        self.sum_of_crates_around_agent()
        # self.agent_in_explosion_zone()
        self.crates_and_agents_explode()
        # self.distance_from_bomb_and_cooldown()
        self.distance_and_rel_coords_and_crates_around_next_agent()
        self.get_agent_pos()
        self.coins_in_radius_3()
        self.distance_and_rel_coords_and_crates_around_coin()
        self.bomb_possible()
        self.scores()
        self.sum_crates()
        self.agent_at_border()
        self.agent_position_relative_to_wall()
        self.search_free_space()
        self.survivable_space()

        return np.array(self.features)

class TreeModel():
    def __init__(self, buffer_size, X_shape, y_shape, min_samples=1, max_leaf_nodes=None, importance_sampling=True):
        self.buffer_X = CircularArray((buffer_size, *X_shape))
        self.buffer_y = CircularArray((buffer_size, *y_shape))
        self.model = tree.DecisionTreeRegressor(min_samples_leaf=min_samples, max_leaf_nodes=None)
        self.fitted = False
        self.importance_sampling = importance_sampling
    
    def fit(self, X, y):
        for i in range(X.shape[0]):
            self.buffer_X.add(X[i])
            self.buffer_y.add(y[i])

        data_X = self.buffer_X.as_array()
        data_y = self.buffer_y.as_array().copy()

        if self.importance_sampling:
            if self.fitted:
                data_pred = self.predict(data_X)
                zeros = np.where(data_y==0)
                data_y[zeros] = data_pred[zeros]
            else:
                data_pred = np.mean(data_y, axis=0)
                zeros = np.where(data_y==0)
                data_y[zeros] = data_pred[zeros[1]]

        self.model.fit(data_X, data_y)
        self.fitted = True

    def add_data(self, X, y):
        for i in range(X.shape[0]):
            self.buffer_X.add(X[i])
            self.buffer_y.add(y[i])
    
    def predict(self, X):
        return self.model.predict(X)
    
    def save(self, path):
        pickle.dump(self.model, open(path, "wb"))

    def load(self, path):
        self.model = pickle.load(open(path, "rb"))

def rotate_game_states(game_state_list, action_list):
    augmented_states = []
    augmented_actions = []
    for game_state, action in zip(game_state_list, action_list):
        mirror = True

        mirror_map = np.array([
            [0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0],
            [1,0,0,0,0,0,0,0,1,1,1,1,1,1,1,0,0],
            [1,1,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0],
            [1,1,1,0,0,0,0,0,1,1,1,1,1,0,0,0,0],
            [1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,0,0],
            [1,1,1,1,1,0,0,0,1,1,1,0,0,0,0,0,0],
            [1,1,1,1,1,1,0,0,1,1,0,0,0,0,0,0,0],
            [1,1,1,1,1,1,1,0,1,0,0,0,0,0,0,0,0],
            [1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1],
            [0,0,0,0,0,0,0,0,1,0,1,1,1,1,1,1,1],
            [0,0,0,0,0,0,0,1,1,0,0,1,1,1,1,1,1],
            [0,0,0,0,0,0,1,1,1,0,0,0,1,1,1,1,1],
            [0,0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1],
            [0,0,0,0,1,1,1,1,1,0,0,0,0,0,1,1,1],
            [0,0,0,1,1,1,1,1,1,0,0,0,0,0,0,1,1],
            [0,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1],
            [0,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0],
        ])

        rotation_map = np.array([
            [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,3],
            [1,1,0,0,0,0,0,0,0,0,0,0,0,0,3,3,3],
            [1,1,1,0,0,0,0,0,0,0,0,0,0,3,3,3,3],
            [1,1,1,1,0,0,0,0,0,0,0,0,3,3,3,3,3],
            [1,1,1,1,1,0,0,0,0,0,0,3,3,3,3,3,3],
            [1,1,1,1,1,1,0,0,0,0,3,3,3,3,3,3,3],
            [1,1,1,1,1,1,1,0,0,3,3,3,3,3,3,3,3],
            [1,1,1,1,1,1,1,1,0,3,3,3,3,3,3,3,3],
            [1,1,1,1,1,1,1,1,2,2,3,3,3,3,3,3,3],
            [1,1,1,1,1,1,1,2,2,2,2,3,3,3,3,3,3],
            [1,1,1,1,1,1,2,2,2,2,2,2,3,3,3,3,3],
            [1,1,1,1,1,2,2,2,2,2,2,2,2,3,3,3,3],
            [1,1,1,1,2,2,2,2,2,2,2,2,2,2,3,3,3],
            [1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,3,3],
            [1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,3],
            [1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],
        ])

        x = game_state['self'][3][0]
        y = game_state['self'][3][1]
        mirror = bool(mirror_map[x, y])
        rot = rotation_map[x, y]

        game_state_rotated = game_state.copy()
        action_rotated = action.copy()

        for _ in range(rot):
            game_state_rotated['field'] = np.rot90(game_state_rotated['field'], 3)
            game_state_rotated['bombs'] = [((b[0][1], 16-b[0][0]), b[1]) for b in game_state_rotated['bombs']]
            game_state_rotated['explosion_map'] = np.rot90(game_state_rotated['explosion_map'], 3)
            game_state_rotated['coins'] = [(b[1], 16-b[0]) for b in game_state_rotated['coins']]
            b = game_state_rotated['self']
            game_state_rotated['self'] = (b[0], b[1], b[2], (b[3][1], 16-b[3][0]))
            game_state_rotated['others'] = [(b[0], b[1], b[2], (b[3][1], 16-b[3][0])) for b in game_state_rotated['others']]

            action_rotated = action_rotated[[3, 2, 0, 1, 4, 5]]

        game_state_mirrored = game_state_rotated.copy()
        action_mirrored = action_rotated.copy()
        if mirror:
            game_state_mirrored['field'] = np.flip(game_state_mirrored['field'], axis=-1)
            game_state_mirrored['bombs'] = [((b[0][0], 16-b[0][1]), b[1]) for b in game_state_mirrored['bombs']]
            game_state_mirrored['explosion_map'] = np.flip(game_state_mirrored['explosion_map'], axis=-1)
            game_state_mirrored['coins'] = [(b[0], 16-b[1]) for b in game_state_mirrored['coins']]
            b = game_state_mirrored['self']
            game_state_mirrored['self'] = (b[0], b[1], b[2], (b[3][0], 16-b[3][1]))
            game_state_mirrored['others'] = [(b[0], b[1], b[2], (b[3][0], 16-b[3][1])) for b in game_state_mirrored['others']]

            action_mirrored = action_mirrored[[1, 0, 2, 3, 4, 5]]
        

        augmented_states.append(game_state_mirrored)
        augmented_actions.append(action_mirrored)
    
    return augmented_states, augmented_actions, rot, mirror

def reverse_rotate_action(label, rot, mirror):
    if rot == 3:
        rot = 1
    elif rot == 1:
        rot = 3

    mirrored_label = label.copy()
    if mirror:
        mirrored_label = mirrored_label[[1, 0, 2, 3, 4, 5]]
    rotated_label = mirrored_label.copy()
    for _ in range(rot):
        rotated_label = rotated_label[[3, 2, 0, 1, 4, 5]]

    return rotated_label

def setup(self):
    if not self.train:
        self.feature_selector = FeatureSelector()
        self.actor = TreeModel(10000, (16,), (6,), 100)
        self.actor.load('actor.p')

def act(self, game_state: dict):
    if self.train:
        if game_state['round'] == 1:
            epsilon = 1
        else:
            epsilon = 0.05+0.5*np.exp(-game_state['round']/200)
    else:
        epsilon = 0.05

    if np.random.random() > epsilon:
        state, action, rot, mir = rotate_game_states([game_state], [np.array([0,0,0,0,0,0])])
        features =  self.feature_selector.eval_all_features(state[0])

        p = self.actor.predict(features.reshape((1, -1)))[0]
        #gent.logger.info(p)
        p = reverse_rotate_action(p, rot, mir)
        action = ['UP', 'DOWN', 'LEFT', 'RIGHT', 'BOMB', 'WAIT'][np.argmax(p)]
        #action = np.random.choice(['UP', 'DOWN', 'LEFT', 'RIGHT', 'BOMB', 'WAIT'], p=softmax(p))

    else: 
        p = np.array([1,1,1,1,0.1,0])
        p /= np.sum(p)
        action = np.random.choice(['UP', 'DOWN', 'LEFT', 'RIGHT', 'BOMB', 'WAIT'], p=p)

    self.logger.info('Pick %s'%action)
    return action
